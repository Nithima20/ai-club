import { Shield, Compass, Users, Sparkles, Brain, Rocket, CalendarDays } from 'lucide-react'
import { AiBackground } from '@/components/landing/ai-background'
import { PortalCard } from '@/components/landing/portal-card'
import { AiClubLogo, CollegeLogo } from '@/components/brand/logos'

const portals = [
  {
    icon: Shield,
    title: 'Staff Portal',
    subtitle:
      'Manage events, members, announcements, reports and every club activity from one command center.',
    href: '/staff',
    cta: 'Enter Staff Portal',
    accent: '#a78bfa',
  },
  {
    icon: Compass,
    title: 'Student Coordinator Portal',
    subtitle:
      'Manage assigned events, registrations, attendance and announcements with coordinator tools.',
    href: '/coordinator',
    cta: 'Enter Coordinator Portal',
    accent: '#38bdf8',
  },
  {
    icon: Users,
    title: 'Club Member Portal',
    subtitle:
      'Register for events, track attendance, view certificates and explore all club activities.',
    href: '/member',
    cta: 'Enter Member Portal',
    accent: '#34d399',
  },
]

const highlights = [
  { icon: Brain, label: 'Hands-on AI Workshops' },
  { icon: Rocket, label: 'Hackathons & Projects' },
  { icon: CalendarDays, label: 'Weekly Paper Readings' },
]

export default function LandingPage() {
  return (
    <main className="relative min-h-dvh overflow-hidden">
      {/* Ambient background layers */}
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(120%_80%_at_50%_-10%,oklch(0.28_0.12_295)_0%,transparent_55%)]" />
      <div
        aria-hidden
        className="absolute inset-0 -z-10 opacity-[0.15] [background-image:linear-gradient(oklch(0.7_0.16_290)_1px,transparent_1px),linear-gradient(90deg,oklch(0.7_0.16_290)_1px,transparent_1px)] [background-size:44px_44px] [mask-image:radial-gradient(80%_60%_at_50%_0%,black,transparent)]"
      />
      <AiBackground />

      {/* Header */}
      <header className="relative z-10 mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-6 py-6">
        <AiClubLogo size={44} showWordmark />
        <CollegeLogo width={190} />
      </header>

      {/* Hero */}
      <section className="relative z-10 mx-auto max-w-7xl px-6 pb-8 pt-10 text-center sm:pt-16">
        <div className="mx-auto inline-flex items-center gap-2 rounded-full border border-border/60 glass px-4 py-1.5 text-xs font-medium text-muted-foreground">
          <Sparkles className="size-3.5 text-primary" />
          Official Digital Platform · AI Club
        </div>

        <h1 className="mx-auto mt-6 max-w-4xl text-balance text-4xl font-bold tracking-tight sm:text-6xl">
          Welcome to the{' '}
          <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent text-glow">
            AI Club
          </span>
        </h1>
        <p className="mx-auto mt-5 max-w-2xl text-pretty text-lg text-muted-foreground sm:text-xl">
          Innovate. Learn. Build the Future with AI.
        </p>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          {highlights.map((h) => (
            <div
              key={h.label}
              className="inline-flex items-center gap-2 rounded-full border border-border/50 bg-secondary/40 px-3.5 py-1.5 text-sm text-muted-foreground"
            >
              <h.icon className="size-4 text-accent" />
              {h.label}
            </div>
          ))}
        </div>
      </section>

      {/* Portals */}
      <section className="relative z-10 mx-auto max-w-6xl px-6 pb-24 pt-8">
        <div className="mb-8 text-center">
          <h2 className="text-2xl font-semibold tracking-tight">Choose your portal</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Role-based access for staff, coordinators and members.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {portals.map((p, i) => (
            <PortalCard key={p.title} {...p} index={i} />
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-border/50">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-6 py-6 text-center text-sm text-muted-foreground sm:flex-row sm:text-left">
          <p>AI Club · CK College of Engineering and Technology</p>
          <p className="text-xs">An Autonomous Institution · CavinKare Patronized Institution</p>
        </div>
      </footer>
    </main>
  )
}
