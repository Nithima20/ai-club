// Placeholder service layer. Every function here is async and returns the same
// shapes a real REST/GraphQL backend would. To connect a backend later, replace
// the mock-data lookups with `fetch()` calls — no UI component needs to change.

import {
  users,
  events,
  registrations,
  attendance,
  announcements,
  projects,
  certificates,
  gallery,
  resources,
  activities,
  reports,
} from '@/data/mock-data'
import type {
  User,
  ClubEvent,
  Registration,
  AttendanceRecord,
  Announcement,
  Project,
  Certificate,
  GalleryItem,
  Resource,
  Activity,
  Report,
  UserRole,
} from '@/types'

// Simulates network latency so loading states behave realistically.
const delay = <T>(data: T, ms = 250): Promise<T> =>
  new Promise((resolve) => setTimeout(() => resolve(data), ms))

export const api = {
  // Users
  getUsers: () => delay(users),
  getUsersByRole: (role: UserRole) => delay(users.filter((u) => u.role === role)),
  getUser: (id: string) => delay(users.find((u) => u.id === id) ?? null),

  // Events
  getEvents: () => delay(events),
  getEvent: (id: string) => delay(events.find((e) => e.id === id) ?? null),
  getEventsByCoordinator: (coordinatorId: string) =>
    delay(events.filter((e) => e.coordinatorId === coordinatorId)),

  // Registrations
  getRegistrations: () => delay(registrations),
  getRegistrationsByUser: (userId: string) =>
    delay(registrations.filter((r) => r.userId === userId)),
  getRegistrationsByEvent: (eventId: string) =>
    delay(registrations.filter((r) => r.eventId === eventId)),

  // Attendance
  getAttendance: () => delay(attendance),
  getAttendanceByUser: (userId: string) =>
    delay(attendance.filter((a) => a.userId === userId)),

  // Announcements
  getAnnouncements: () => delay(announcements),

  // Projects
  getProjects: () => delay(projects),
  getProjectsByMember: (userId: string) =>
    delay(projects.filter((p) => p.members.includes(userId))),

  // Certificates
  getCertificates: () => delay(certificates),
  getCertificatesByUser: (userId: string) =>
    delay(certificates.filter((c) => c.userId === userId)),

  // Gallery
  getGallery: () => delay(gallery),

  // Resources
  getResources: () => delay(resources),

  // Activities
  getActivities: () => delay(activities),

  // Reports
  getReports: () => delay(reports),
}

export type {
  User,
  ClubEvent,
  Registration,
  AttendanceRecord,
  Announcement,
  Project,
  Certificate,
  GalleryItem,
  Resource,
  Activity,
  Report,
}
