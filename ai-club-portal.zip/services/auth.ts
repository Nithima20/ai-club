// Mock authentication + role-based access scaffold.
// Currently role selection is simulated. Swap these functions for real calls to
// an auth backend (Better Auth / Supabase / custom) without changing consumers.

import type { User, UserRole } from '@/types'
import { users } from '@/data/mock-data'

const SESSION_KEY = 'ai-club-session'

// A representative user for each role, used when a portal is entered directly.
const roleDefaults: Record<UserRole, string> = {
  staff: 'u1',
  coordinator: 'u2',
  member: 'u3',
}

export const auth = {
  // Simulated login by role selection.
  loginAs(role: UserRole): User {
    const user = users.find((u) => u.id === roleDefaults[role]) ?? users[0]
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(SESSION_KEY, JSON.stringify({ userId: user.id, role }))
    }
    return user
  },

  getSession(): { userId: string; role: UserRole } | null {
    if (typeof window === 'undefined') return null
    const raw = window.localStorage.getItem(SESSION_KEY)
    return raw ? JSON.parse(raw) : null
  },

  getCurrentUser(fallbackRole: UserRole): User {
    const session = this.getSession()
    const id = session?.userId ?? roleDefaults[fallbackRole]
    return users.find((u) => u.id === id) ?? users[0]
  },

  logout() {
    if (typeof window !== 'undefined') {
      window.localStorage.removeItem(SESSION_KEY)
    }
  },
}
